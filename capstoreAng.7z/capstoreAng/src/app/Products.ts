export interface Products{
    productId:number;
	productName:string;
	productCategory:string;
	productPrice:number;
	productsSold:number;
	productView:number;
	quantity:number;
	brand:string;
}