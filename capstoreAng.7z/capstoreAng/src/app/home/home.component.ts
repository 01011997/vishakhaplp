import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SearchService } from '../search.service';
import { Products } from '../Products';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  /* product:Products[];
  /* @Input() search:Products; */
  constructor(private router: Router,private service:SearchService) { }

  
 
  ngOnInit() {
    
  }

  navigateToSearch() {
    this.router.navigate(['/search']);
  }

  navigateToSort() {
    this.router.navigate(['/sort']);
  }
}
