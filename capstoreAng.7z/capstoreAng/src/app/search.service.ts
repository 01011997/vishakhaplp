import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Products } from './Products';

 const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type' : 'application/json'})
} 

@Injectable({
  providedIn: 'root'
})
export class SearchService {
 
  constructor(private http:HttpClient) { 
    this.getProduct().subscribe(data=>this.product=data)
    /*Sort mobile in Ascending order*/
    this.sortProductAsc().subscribe(data=>this.sortasc=data)
        /*Sort mobile in Descending order*/
    this.sortProductDesc().subscribe(data=>this.sortdesc=data)
    

  }

  product:Products[];
  getProduct():any{
    return this.http.get<Products>("http://localhost:8087/capstore/api/v1/productCategory/Mobile");
  }

  sortasc:Products[];
  sortProductAsc():any{
    return this.http.get<Products>("http://localhost:8087/capstore/api/v1//Mobile/lowtohigh");
  }

  sortdesc:Products[];
  sortProductDesc():any{
    return this.http.get<Products>("http://localhost:8087/capstore/api/v1//Mobile/hightolow");
  }

  getSearch():Products[]{
    //alert("Capstore");
    console.log(this.product);
    return this.product;
  } 

  getSortAsc():Products[]{
    //alert("Capstore");
    console.log(this.sortasc);
    return this.sortasc;
  } 

  getSortDesc():Products[]{
    //alert("Capstore");
    console.log(this.sortdesc);
    return this.sortdesc;
  } 
}
