import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Products } from '../Products';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.css']
})
export class SortComponent implements OnInit {
  product:Products[];
  /* @Input() search:Products; */
  constructor(private router: Router,private service:SearchService) { }

  ngOnInit() {
  }

  getSortAsc()
  {
    this.product=<Products[]>this.service.getSortAsc();
  } 

  getSortDesc()
  {
    this.product=<Products[]>this.service.getSortDesc();
  } 

}
