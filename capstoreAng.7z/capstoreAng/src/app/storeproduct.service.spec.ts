import { TestBed } from '@angular/core/testing';

import { StoreproductService } from './storeproduct.service';

describe('StoreproductService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StoreproductService = TestBed.get(StoreproductService);
    expect(service).toBeTruthy();
  });
});
