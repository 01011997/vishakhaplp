package com.capstore.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capstore.model.Customer;
import com.capstore.model.Inventory;
import com.capstore.model.Merchant;
import com.capstore.model.Product;
import com.capstore.service.CustomerService;
import com.capstore.service.IProductService;
import com.capstore.service.MerchantService;


@RestController
@CrossOrigin("*")
@RequestMapping("/api/v1")
public class AdminController {
	
	public CustomerService customerService;
	
	@Autowired
	public MerchantService merchantService;
	
	
	@Autowired
	IProductService productService;
	
	


	@GetMapping(value = "/customers/all")
	public ResponseEntity<java.util.List<Customer>> getAllCustomers() {
		System.out.println("");
		java.util.List<Customer> list_of_customers = customerService.getAllCustomers();
		System.out.println("Controller"+list_of_customers);
		if (list_of_customers==null) {
			new ResponseEntity("No Customers found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<java.util.List<Customer>>(list_of_customers, HttpStatus.OK);
	}
	
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<Customer> getcustomer(@PathVariable int customerId){
		Customer customer=customerService.getCustomerByCustomerId(customerId);
		if(customer==null)
			return new ResponseEntity("Sorry! Can't find customer with this Id!",HttpStatus.NOT_FOUND);
		else
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	
	
	
	@GetMapping(value = "/merchants/all")
	public ResponseEntity<List<Merchant>> getAllMerchants() {
		System.out.println("");
		java.util.List<Merchant> list_of_merchant = merchantService.getAllMerchants();
		System.out.println("Controller"+list_of_merchant);
		if (list_of_merchant==null) {
			new ResponseEntity("No Customers found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<java.util.List<Merchant>>(list_of_merchant, HttpStatus.OK);
	}
	
	
	@GetMapping("/viewProducts")
	public ResponseEntity<List<Product>> getAllProducts(){
		
		List<Product> products=productService.getAllProducts();
		if(products.isEmpty())
			 return new ResponseEntity("Sorry ! Inventories not available!",HttpStatus.NOT_FOUND);
		
		
		return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
		
	}
			
	
	/*@GetMapping("/viewInventories")
	public ResponseEntity<List<Inventory>> getInventoriesList(){
		
		
		List<Inventory> inventories=inventoryMerchantService.getInventoriesList();
		if(inventories.isEmpty())
			 return new ResponseEntity("Sorry ! Inventories not available!",HttpStatus.NOT_FOUND);
		
		
		return new ResponseEntity<List<Inventory>>(inventories,HttpStatus.OK);
		
	}*/
	
	
}
