package com.capstore.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.model.Inventory;
import com.capstore.model.Product;

@Repository("inventoryRepository")
@Transactional
public interface InventoryRepository extends JpaRepository<Inventory,Integer> {

}
