package com.capstore.service;

import java.util.List;

import com.capstore.model.Inventory;
import com.capstore.model.Product;

public interface IProductService {

	public List<Product> getAllProducts();
	
	public Product getProduct(int productId);

	public void add(Product product);

	public void add(Inventory inventory);
	public List<Product> getProductsByCategory(String productCategory);
	public Product getProductByProductId(int productId);

	public Product getProductByProductName(String productName);

	//public List<Product> getProductsAsc(String productCategory);
	/*public List<Product> findAllProductsByPriceAsc();

	public List<Product> findAllProductsByPriceDesc();*/



}
