package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.MerchantRepository;
import com.capstore.model.Merchant;


@Service("merchantService")
public class MerchantService {
	@Autowired
	MerchantRepository merchantDao;
	public List<Merchant> getAllMerchants() {
		return merchantDao.findAll();
	}




}
