package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capstore.dao.InventoryRepository;
import com.capstore.dao.ProductRepository;
import com.capstore.model.Inventory;
//import com.capstore.model.Merchant;
import com.capstore.model.Product;

@Service("productService")
public class ProductService implements IProductService{

	@Autowired
	private ProductRepository productDao;
	
	@Autowired
	private InventoryRepository inventoryDao;
	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}

	@Override
	public Product getProduct(int productId) {
		Optional<Product> optional = productDao.findById(productId);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
	
	public Product getProductByProductId(int productId) {
		Optional<Product> optional = productDao.findById(productId);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
	
	@Override
	public List<Product> getProductsByCategory(String productCategory) {
		return productDao.findByproductCategoryOrderByProductViewDesc(productCategory);

	}

	@Override
	public void add(Product product) {
		productDao.save(product);
		
	}

	@Override
	public void add(Inventory inventory) {
		inventoryDao.save(inventory);
		
	}

	@Override
	public Product getProductByProductName(String productName) {
		return productDao.getProductByProductNameOrderByProductViewAsc(productName);

	}

	/*@Override
    public List<Product> findAllProductsByPriceAsc() {

        Sort sort = new Sort(Sort.Direction.ASC, "productPrice");
        return productDao.findAllProductsByPriceAsc(sort);
    }

	@Override
	public List<Product> findAllProductsByPriceDesc() {
        Sort sort = new Sort(Sort.Direction.ASC, "productPrice");
        return productDao.findAllProductsByPriceDesc(sort);

	}
*/
	
}