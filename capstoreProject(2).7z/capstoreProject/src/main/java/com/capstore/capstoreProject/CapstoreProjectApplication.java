package com.capstore.capstoreProject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.capstore.model.Inventory;
import com.capstore.model.Product;
import com.capstore.service.IProductService;

@EnableJpaRepositories(basePackages="com.*")
@EntityScan(basePackages="com.*")
@ComponentScan(basePackages="com.*")
@SpringBootApplication
public class CapstoreProjectApplication implements CommandLineRunner{
	@Autowired
	private IProductService productService;

	public static void main(String[] args) {
		SpringApplication.run(CapstoreProjectApplication.class, args);
		
		

	}

	@Override
	public void run(String... args) throws Exception {
		productService.add(new Product(100, "Redmi","Mobile", 15000, 110, 130,66,"MI") );
		productService.add(new Product(101, "Samsung Note","Mobile", 19000, 160, 200,70,"Samsung") );
		productService.add(new Product(102, "Nokia 5.1 plus","Mobile", 14000, 100, 130,75,"Nokia") );
		productService.add(new Product(103, "vivo y91","Mobile", 10000, 90, 100,50,"Vivo") );
		
		productService.add(new Product(104, "Top","Fashion", 1000, 30, 94,66,"Vero Moda") );
		productService.add(new Product(105, "Dress","Fashion", 2999, 12, 104,46,"People") );
		
		



		/*productService.add(new Inventory(1000, "asgdf", "Mobile", 6) );
		productService.add(new Inventory(1001, "irgh", "Mobile", 9) );*/
		
	}

}
