package com.capstore.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capstore.model.Inventory;
import com.capstore.model.Product;

@Repository("productRepository")
@Transactional
public interface ProductRepository extends JpaRepository<Product,Integer> {


	@Query("from Product WHERE  productCategory=:productCategory AND productPrice>=:min AND  productPrice<:max")
	public List<Product> getProductsInRange(String productCategory, double min, double max);

	@Query("from Product WHERE product_id=:productId")
	public Product getProductByProductId(int productId);
    

	public void save(Inventory inventory);

	public List<Product> findByproductCategoryOrderByProductViewDesc(String productCategory);

	public Product getProductByProductName(String productName);

	public Product getProductByProductNameOrderByProductViewAsc(String productName);

	public List<Product> findByProductCategoryOrderByProductPrice(String productCategory);

	public List<Product> findByProductCategoryOrderByProductPriceDesc(String productCategory);

	/*public List<Product> findAllProductsByPriceAsc(Sort sort);
	
	public List<Product> findAllProductsByPriceDesc(Sort sort);
	
	@Query("FROM Products ORDER BY productprice ASC")
    List<Product> findAllProductsByPriceAsc();
	
	@Query("FROM Products ORDER BY productprice Desc")
    List<Product> findAllProductsByPriceDesc();*/
}
