package com.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.CustomerRepository;
import com.capstore.dao.ProductRepository;
import com.capstore.model.Customer;

@Service("customerService")
public class CustomerService {

	@Autowired
	private CustomerRepository customerDao;
	
	public List<Customer> getAllCustomers() {
		return customerDao.findAll();
	}


	public Customer getCustomerByCustomerId(int customerId) {
		Optional<Customer> optional = customerDao.findById(customerId);
		if(optional.isPresent()) {
			return optional.get();
		}		
		return null;
	}

}
