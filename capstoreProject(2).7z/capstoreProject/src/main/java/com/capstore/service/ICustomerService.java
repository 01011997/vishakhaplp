package com.capstore.service;

import java.util.List;

import com.capstore.model.Customer;


public interface ICustomerService {

	public List<Customer> getAllCustomers();

	public Customer getCustomerById(int customerId);

}
