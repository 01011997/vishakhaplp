package com.capstore.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capstore.dao.InventoryRepository;
import com.capstore.dao.ProductRepository;
import com.capstore.model.Inventory;
//import com.capstore.model.Merchant;
import com.capstore.model.Product;

@Service("productService")
public class ProductService implements IProductService{

	@Autowired
	private ProductRepository productDao;
	
	@Autowired
	private InventoryRepository inventoryDao;
	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}

	@Override
	public Product getProduct(int productId) {
		Optional<Product> optional = productDao.findById(productId);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
	
	public Product getProductByProductId(int productId) {
		Optional<Product> optional = productDao.findById(productId);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
	
	@Override
	public List<Product> getProductsByCategory(String productCategory) {
		return productDao.findByproductCategoryOrderByProductViewDesc(productCategory);

	}

	@Override
	public void add(Product product) {
		productDao.save(product);
		
	}

	@Override
	public void add(Inventory inventory) {
		inventoryDao.save(inventory);
		
	}

	@Override
	public Product getProductByProductName(String productName) {
		Product prod=new Product();
		List<Product>list=productDao.findAll();
		Iterator itr=list.iterator();
		while(itr.hasNext()) {
			prod=(Product) itr.next();
			if(prod.getProductName()==productName) {
				return prod;
			}
		}
		return productDao.getProductByProductNameOrderByProductViewAsc(productName);

	}
	
	@Override
	public Product getProductByProductBrand(String brand) {
		Product prod=new Product();
		List<Product>list=productDao.findAll();
		Iterator itr=list.iterator();
		while(itr.hasNext()) {
			prod=(Product) itr.next();
			if(prod.getBrand()==brand) {
				return prod;
			}
		}
		return productDao.getProductByProductNameOrderByProductViewAsc(brand);
	}

	@Override
	public List<Product> getProductsAsc(String productCategory) {
List<Product> products=productDao.findByProductCategoryOrderByProductPrice(productCategory);
		
		return products;
	}

	@Override
	public List<Product> getProductsDesc(String productCategory) {
		List<Product> products1=productDao.findByProductCategoryOrderByProductPriceDesc(productCategory);
		return products1;
	}

	@Override
	public List<Product> getProductsInRange(String productCategory, double min, double max) {
		List<Product> inrangeproduct = productDao.getProductsInRange(productCategory,min,max);
		return inrangeproduct;
	}

	

	/*@Override
	public List<Product> getProductsDesc(String productCategory) {
		// TODO Auto-generated method stub
		return null;
	}*/

	
}