import { MostView } from './mostView';
import { Inventory } from './inventory';

export class ModelCap{
    id: number;
    catId: number;
    name: String;
    brand: String;
    price: number;
     mostView:MostView;
     inventory:Inventory;
}