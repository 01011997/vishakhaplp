export class MostView{ 
id:number;
 viewCount:number;
soldCount:number;
    
}
